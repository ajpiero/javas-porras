 // Hamburgueseria - Carrito de Compras 
 
Si tiene problemas para cargar index.html por error: "Fetch API cannot load due to access control checks" after reload, escribir en cmd: open /Applications/Google\ Chrome.app --args --allow-file-access-from-files, antes de volver a abrir el archivo.

Alonso.-